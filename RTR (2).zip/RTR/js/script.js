var colors = {
    'social': '#367d85',
    'environment': '#edbd00',
    'animals': '#97ba4c',
    'health': '#f5662b',
    'fallback': '#232e35',
    'research_ingredient': '#3f3e47'

};

var outputData;
var graphData = {};
var chartHeight = {};
var rule = "";

document.getElementById('file').addEventListener('change', onChange);


function onChange(event) {

    var reader = new FileReader();

    var inputs = document.querySelectorAll('.fileInput');
    var el = inputs[0];

    const fileInput = el.querySelector('[type="file"]');
    const label = el.querySelector('[data-js-label]');

    $("#chart").empty();
    $(".primaryUnrelated , .secondaryUnrelated").empty();


    if (!fileInput.value) return;

    var value = fileInput.value.replace(/^.*[\\\/]/, '');

    el.className += ' -chosen';
    label.innerText = value;

    reader.onload = onReaderLoad;
    reader.readAsText(event.target.files[0]);

}

function onReaderLoad(event){
   outputData = JSON.parse(event.target.result);

   rule = outputData["Rule"];

   processOutputData(outputData);
   processRule(rule);

}



// $.ajax({
//     type: "GET",
//     url: "../output1.json",
//     dataType: 'text',
//     cache: false,
//     contentType: "application/json; charset=utf-8;",
//      // This does not work with JSONP, nor should you be using it anyway.
//      // It will lock up the browser
//      async: false,
//      beforeSend: function () {
//          console.log("Loading");
//      },
//
//      error: function (jqXHR, textStatus, errorThrown) {
//          console.log(jqXHR);
//          console.log(textStatus);
//          console.log(errorThrown);
//      },
//
//      success: function (data) {
//          //processOutputData(JSON.parse(data));
//
//          var data = JSON.stringify(data);
//          data = JSON.parse(data);
//          processOutputData(data);
//      },
//
//      complete: function () {
//          console.log('Finished all tasks');
//      }
// });

function processRule(ruleStr){

  $(".infoContainer").empty();

  ruleStr = ruleStr.split(/[()]/).filter(Boolean);

  for(var i in ruleStr){

      if(ruleStr[i].trim() == "<&&>"){
        ruleStr[i] = "and";
      }else if(ruleStr[i].trim() == "<||>"){
        ruleStr[i] = "or";
      }

  }

  for(var i in ruleStr){
    if(ruleStr[i] == "and" || ruleStr[i] == "and" ){
      var ele = '<div class="connectionDiv"><a href="#" class="arrow left"></a><span>'+ruleStr[i].toUpperCase()+'</span><a href="#" class="arrow right"></a></div>';
      $(".infoContainer").append(ele);

    }else{
      var ele = '<div class="ruleElement"><pre>'+ruleStr[i].replace(/</g, '&lt;').replace(/>/g, '&gt;');+'<pre></div>'
      $(".infoContainer").append(ele);
    }
  }
}


function processOutputData(dataVal) {


    var PrimaryData = dataVal.PrimaryData;
    var SecondaryData = dataVal.SecondaryData;


    var matchedPrimary = PrimaryData.filter(function(data) {
        return data.RefID_AI != "none";
    });

    var matchedSecondary = SecondaryData.filter(function(data) {
        return data.RefID_AI != "none";
    });



    var unmatchedPrimary = PrimaryData.filter(function(data) {
        return data.RefID_AI == "none";
    });

    var unmatchedSecondary = SecondaryData.filter(function(data) {
        return data.RefID_AI == "none";
    });

    var AllMatchedNodes = [];

    for (var i in matchedPrimary) {
        var obj = {};
        obj["name"] = "Rec_ID_" + matchedPrimary[i].ReconciledId;
        obj["id"] = matchedPrimary[i].ReconciledId;
        obj["refId"] = matchedPrimary[i].RefID_AI;
        AllMatchedNodes.push(obj);
    }


    for (var i in matchedSecondary) {
        var obj = {};
        obj["name"] = "Rec_ID_" + matchedSecondary[i].ReconciledId;
        obj["id"] = matchedSecondary[i].ReconciledId;
        obj["refId"] = matchedSecondary[i].RefID_AI;
        AllMatchedNodes.push(obj);
    }

    chartHeight = Math.max(matchedPrimary.length ,matchedSecondary.length ) * 35;

    var links = [];

    for (var i in matchedPrimary) {

        var obj = matchedSecondary.filter(function(data) {
            return data.RefID_AI == matchedPrimary[i].RefID_AI;
        });
        for (var j in obj) {
            var linkObj = {};

            linkObj["source"] = AllMatchedNodes.findIndex(data => data.id == matchedPrimary[i].ReconciledId);
            linkObj["target"] = AllMatchedNodes.findIndex(data => data.id == obj[j].ReconciledId);
            linkObj["value"] = 1;
            links.push(linkObj);

        }

    }

    if(unmatchedPrimary.length > 0){
      for (var j in unmatchedPrimary) {
          var ele = '<div class="uNodeleft" id=' + unmatchedPrimary[j].ReconciledId + '>' + "Rec_ID_" + unmatchedPrimary[j].ReconciledId + '</div>';
          $(".primaryUnrelated").append(ele);

      }
    }

  if(unmatchedSecondary.length > 0){
    for (var k in unmatchedSecondary) {
        var ele = '<div class="uNoderight" id=' + unmatchedSecondary[k].ReconciledId + '>' + "Rec_ID_" + unmatchedSecondary[k].ReconciledId + '</div>';
        $(".secondaryUnrelated").append(ele);

      }
    }

    graphData["nodes"] = AllMatchedNodes;
    graphData["links"] = links;
    createChart();

}

function createChart() {

    var chart = d3.select("#chart").append("svg")
        .style('height',chartHeight)
        .chart("Sankey.Path");

    chart
        .name(label)
        .colorNodes(function(name, node) {
            return color(node, 3) || color(node, 2) || color(node, 1) || colors.fallback;
        })
        .colorLinks(function(link) {
            return color(link.source, 4) || color(link.target, 1) || colors.fallback;
        })
        .nodeWidth(10)
        .nodePadding(10)
        .iterations(0)
        .draw(graphData);

    var link = d3.select("#chart").select("svg")
        .selectAll(".link")
        .attr("class", "link")
        .on('click', linkOnMouseClick);

}

function linkOnMouseClick(event) {

    $(".detailsDiv").remove();

    var sourceArrayID = [];

    for (var i in event.target.targetLinks){
      sourceArrayID.push(event.target.targetLinks[i].source.id)
    }

    for(var j in sourceArrayID){
      var sourceElement  = outputData.PrimaryData.filter(function(data) {
           return data.ReconciledId == sourceArrayID[j];
      });

      var ele = '<div class=detailsDiv><p>'+
                '<b>Reference Invoice Number: </b>'+sourceElement[0]["Reference Invoice Number"]+'</p>'+
                '<p><b>Amount in Doc Currency: </b>'+sourceElement[0]["Amount in Doc Currency"]+'</p>'+
                '<p><b>Doc Currency: </b>'+sourceElement[0]["Doc Currency"]+'</p><hr></div>';

      $(".primaryDetails").append(ele);
    }

    var targetArrayID = [];

    for (var i in event.source.sourceLinks){
      targetArrayID.push(event.source.sourceLinks[i].target.id)
    }

    for(var j in targetArrayID){
      var sourceElement  = outputData.SecondaryData.filter(function(data) {
           return data.ReconciledId == targetArrayID[j];
      });

      var ele = '<div class=detailsDiv><p>'+
                '<b>Reference Invoice Number: </b>'+sourceElement[0]["Reference Invoice Number"]+'</p>'+
                '<p><b>Amount in Doc Currency: </b>'+sourceElement[0]["Amount in Doc Currency"]+'</p>'+
                '<p><b>Doc Currency: </b>'+sourceElement[0]["Doc Currency"]+'</p><hr></div>';

      $(".secondaryDetails").append(ele);
    }

}



function label(node) {
    return node.name.replace(/\s*\(.*?\)$/, '');
}

function color(node, depth) {
    var id = node.id % 5;
    if (colors[id]) {
        return colors[id];
    } else if (depth > 0 && node.targetLinks && node.targetLinks.length == 1) {
        return color(node.targetLinks[0].source, depth - 1);
    } else {
        return null;
    }
}
